var elem = document.querySelector("#scroll-section");
var scrollbar = Scrollbar.init(elem,
{
	speed: 0.7,
	damping:0.04
});
var bSection = document.getElementById('b-section');
scrollbar.addListener(function (status) {
	console.log(status);
});